import torch.nn

import mdl_layers_louizos as mdll

alphabet_dict = {'S': 1, "a": 2, "b": 3, "c": 4, "d": 5}


def alphabet_map(c):
    return alphabet_dict[c]


def lang_to_tensor(language: dict):
    '''
    :param language: dict of tuples to words
    :return: pair of tensors
    '''

    attributes = []
    words = []
    for attr, word in language.items():
        attributes.append(torch.tensor(attr))
        words.append(torch.tensor(list(map(alphabet_map, word))))
    attributes = torch.stack(attributes, dim=0)
    words = torch.nn.utils.rnn.pad_sequence(words, batch_first=True)
    return attributes, words


class LangModelLouizos(torch.nn.Module):

    def __init__(self, num_attributes: int, num_features: int, num_layers: int, alphabet_sz: int, width: int,
                 lam: float, weight_decay: float = 0):
        '''
        :param num_attributes: number of attributes, or length of tuple used
        :param num_features: number of values each attribute can take
        :param alphabet_sz: size of alphabet
        :param width: width of network
        :param lam: L_0 penalty
        :param weight_decay: L_2 penalty
        '''
        super(LangModelLouizos, self).__init__()
        self.lam = lam
        self.weight_decay = weight_decay
        self.embeddings = torch.nn.ModuleList([
                            mdll.RegEmbedding(num_features, width, lam, weight_decay) for i in range(num_attributes)
        ])
        self.compressor = mdll.RegLinear(width*num_attributes, width, lam, weight_decay)
        self.lstm = mdll.RegLSTM(width, width, lam, num_layers, False, weight_decay)
        self.decoder = mdll.RegLinear(width, alphabet_sz, lam, weight_decay)

    def reset_parameters(self):
        for m in self.embeddings:
            m.reset_parameters()
        self.compressor.reset_parameters()
        self.lstm.reset_parameters()
        self.decoder.reset_parameters()

    def constrain_parameters(self):
        for m in self.embeddings:
            m.constrain_parameters()
        self.compressor.constrain_parameters()
        self.lstm.constrain_parameters()
        self.decoder.constrain_parameters()


    def set_lam(self, lam: float):
        self.lam = lam
        for m in self.embeddings:
            m.set_lam(lam)
        self.compressor.set_lam(lam)
        self.lstm.set_lam(lam)
        self.decoder.set_lam(lam)

    def set_wd(self, wd):
        self.wd = wd
        for m in self.embeddings:
            m.set_wd(wd)
        self.compressor.set_wd(wd)
        self.lstm.set_wd(wd)
        self.decoder.set_wd(wd)

    def regularization(self):
        reg = torch.Tensor([0.])
        for m in self.embeddings:
            reg = reg + m.regularization()
        reg = reg + self.compressor.regularization()
        reg = reg + self.lstm.regularization()
        reg = reg + self.decoder.regularization()
        return reg

    def count_l0(self):
        l0 = torch.Tensor([0.])
        for m in self.embeddings:
            l0 = l0 + m.count_l0()
        l0 = l0 + self.compressor.count_l0()
        l0 = l0 + self.lstm.count_l0()
        l0 = l0 + self.decoder.count_l0()
        return l0

    def count_l2(self):
        l2 = torch.Tensor([0.])
        for m in self.embeddings:
            l2 = l2 + m.count_l2()
        l2 = l2 + self.compressor.count_l2()
        l2 = l2 + self.lstm.count_l2()
        l2 = l2 + self.decoder.count_l2()
        return l2

    def forward(self, attribute, longest_str):
        '''
        :param attribute: LongTensor of shape Batch x Attribute
        :param longest_str: int of the longest string in output
        :return: FloatTensor of logits
        '''

        embedding = torch.cat([self.embeddings[i](attribute[:,i], block_sample=True) for i in range(attribute.shape[1])], dim=1)
        compressed_embedding = self.compressor(embedding, block_sample=True).unsqueeze(dim=1)
        expanded_compressed_embedding = compressed_embedding.expand(-1, longest_str, -1)
        lstm_output, _ = self.lstm(expanded_compressed_embedding, block_sample=True)
        logits = self.decoder(lstm_output, block_sample=True)

        return logits


def train_encoder(language: dict, epochs: int, print_every: int, patience: int, **model_args):
    '''
    :param language:
    :param epochs:
    :param print_every:
    :param model_args:
    :return:
    '''
    language = {k: v+'S' for k,v in language.items()}
    attributes, message = lang_to_tensor(language)
    max_len = message.shape[1]
    mask = message != 0
    model = LangModelLouizos(**model_args)
    optim = torch.optim.Adam(model.parameters())
    loss_func = torch.nn.CrossEntropyLoss()
    model.reset_parameters()
    patience_count = 0
    best_loss = float("inf")

    for i in range(epochs):
        optim.zero_grad()
        out = model(attributes, max_len)
        ce_loss = loss_func(out[mask], message[mask])
        l0_penalty = model.regularization()
        loss = ce_loss + l0_penalty
        loss.backward()
        optim.step()

        if i % print_every == 0:
            print("epoch: {}, loss: {}, l0: {}".format(i, ce_loss.item(), l0_penalty.item()))

        if loss < best_loss:
            best_loss = loss
            best_state = model.state_dict()
            patience_count = 0
        else:
            patience_count += 1

        if patience_count > patience:
            model.load_state_dict(best_state) # guaranteed to exist so long as we get a loss better than infinity

            model.eval()
            out = model(attributes, max_len)
            eval_loss = loss_func(out[mask], message[mask])

            return model, eval_loss.item()

    model.load_state_dict(best_state) # guaranteed to exist so long as we get a loss better than infinity

    model.eval()
    out = model(attributes, max_len)
    eval_loss = loss_func(out[mask], message[mask])
    return model, eval_loss.item()


import language_gen as lg

# run parameters (to-do, move these to arge_parse)

lambdas = torch.tensor(list(range(-12, -41, -4))) / 10
lambdas = list(reversed([10 ** x.item() for x in list(lambdas)]))

experiments = 10

num_epochs = 20000  # this is very high, however patience will often stop this early, and data is only 4 mappings
patience = 50

filename_mixture = "mixture_data"
filename_comparison = "comparison_data"
import csv

with open(filename_comparison+".csv", 'w', newline='') as model_data_file:
    writer_data = csv.writer(model_data_file)
    writer_data.writerow(["trial number", "language", "lambda", "eval loss", "l0"])
    # mixture model experiments
    for i in range(experiments):
        # create compositional language
        compositional = lg.comp_lang_gen_fixed(2, 4, ["a", "b", "c"], 4)
        # generate holistic language
        holistic = lg.hol_lang_gen_fixed(2, 4, ["a", "b", "c"], 8)
        # generate nonconcatenative language
        nonconcatenative = lg.circum_lang_gen_fixed(2, 4, ["a", "b", "c"], 2)

        languages = [compositional, holistic, nonconcatenative]
        language_names = ["compositional", "holistic", "nonconcatenative"]
        for j, language in enumerate(languages):
            for lam in lambdas:
                model_params = {'num_attributes': 2, 'num_features': 4, 'num_layers': 2, 'alphabet_sz': 5,
                                'width': 50, 'lam': lam, 'weight_decay': 0}
                best_model_hol, eval_loss = train_encoder(language, num_epochs, 10, patience, **model_params)
                l0 = best_model_hol.count_l0().item()

                writer_data.writerow([i, language_names[j], lam, eval_loss, l0])
                print(f"Experiment: {i}, language {language_names[j]}, "
                      f"lambda: {lam}, best loss: {eval_loss}, l0: {l0}")
#
# with open(filename_mixture+".csv", 'w', newline='') as model_data_file:
#     writer_data = csv.writer(model_data_file)
#     writer_data.writerow(["trial number", "percent holistic", "lambda", "eval loss", "l0"])
#     # mixture model experiments
#     for i in range(experiments):
#         # create compositional language
#         compositional = lg.comp_lang_gen_fixed(2,4,["a","b","c"],3)
#
#         # generate holistic language without vocabulary in compositional language
#         used = compositional.values()
#         holistic = lg.hol_lang_gen_fixed(2,4,["a","b","c"],6)
#         while any([w in compositional.values() for w in holistic.values()]):
#             holistic = lg.hol_lang_gen_fixed(2, 4, ["a", "b","c"], 6)
#
#         # create language mixtures
#         import random
#         compositional_list = list(compositional.items())
#         holistic_list = list(holistic.items())
#         combine = list(zip(holistic_list, compositional_list))
#         random.shuffle(combine)
#         holistic_list, compositional_list = zip(*combine)
#         languages = [dict(holistic_list[:i] + compositional_list[i:]) for i in range(17)]
#
#         percent_holistic = [i/16 for i in range(17)]
#
#         # complexity measurement
#         for j, language in enumerate(languages):
#             if j % 4 == 0:
#                 for lam in lambdas:
#                     model_params = {'num_attributes': 2, 'num_features': 4, 'num_layers': 2, 'alphabet_sz': 5,
#                                     'width': 50, 'lam': lam, 'weight_decay': 0}
#                     best_model_hol, eval_loss = train_encoder(language, num_epochs, 10, patience, **model_params)
#                     l0 = best_model_hol.count_l0().item()
#
#                     writer_data.writerow([i, percent_holistic[j], lam, eval_loss, l0])
#                     print(f"Experiment: {i}, percent holistic {percent_holistic[j]}, "
#                           f"lambda: {lam}, best loss: {eval_loss}, l0: {l0}")
#







