rm(list = ls())
library(tidyverse)

pareto <- function(data, x, y, convex=TRUE){
  
  pareto.1 <- logical(length(data[,x]))
  x.sort <- sort(data[,x])
  y.sort <- data[,y][order(data[,x])]
  
  for(i in 1:length(x.sort)){
    pareto.1[i] <- all(y.sort[1:i] >= y.sort[i])
  }
  
  if(convex){
    chull.df <- data.frame(x=x.sort,y=y.sort,pareto=pareto.1)
    chull.filtered = chull.df[chull.df$pareto & is.finite(chull.df$x) & is.finite(chull.df$y),]
    indices <- chull(chull.filtered$x, chull.filtered$y)
    hull_points <- rownames(chull.filtered)[indices]
    chull.df$convex <- rownames(chull.df) %in% hull_points
    pareto.1 = chull.df$convex
  }
  
  return(pareto.1[match(1:length(data[,x]), order(data[,x]))])
}



add_pareto <- function(data, group, x, y, max_x, max_y){
  groups = unique(data[,group])
  edited_data = list()
  for(g in groups){
    data_subset = data %>% filter(data[,group] == g)
    data_subset$is.pareto <- pareto(data_subset, x, y)
    end_point = data_subset[nrow(data_subset),]
    end_point[,group] = g
    end_point[,x] = max_x
    end_point[,y] = 0
    end_point$is.pareto=TRUE
    edited_data[[g]] = bind_rows(data_subset, end_point)
  }
  return(bind_rows(edited_data))
}


rect_under_pareto <- function(data, group, factor, x, y, max_x, max_y){
  data_subset = data %>% filter(data[,group] == factor)
  data_subset$is.pareto <- pareto(data_subset, x, y)
  pareto_points = filter(data_subset, is.pareto)
  pareto_points = pareto_points[order(pareto_points[,x]),]
  start = c(0, max_y)
  area = 0
  
  old_p = start
  
  for(row in  1:nrow(pareto_points)){
    p = c(pareto_points[row, x], pareto_points[row, y])
    
    dx = (p-old_p)[[1]]
    trap_a = (dx * old_p[[2]])
    area = area + trap_a
    old_p = p
    
  }
  
  p = c(max_x, 0)
  dx = (p-old_p)[[1]]
  trap_a = (dx * old_p[[2]])
  area = area + trap_a
  return(area)
}

trap_under_pareto <- function(data, group, factor, x, y, max_x, max_y, min_x, min_y){
  data_subset = data %>% filter(data[,group] == factor)
  data_subset$is.pareto <- pareto(data_subset, x, y)
  pareto_points = filter(data_subset, is.pareto)
  pareto_points = pareto_points[order(pareto_points[,x]),]
  start = c(pareto_points[1, x], pareto_points[1, y])
  area = 0
  
  old_p = start
  
  for(row in  2:nrow(pareto_points)){
    p = c(pareto_points[row, x], pareto_points[row, y])
    if(p[[2]] < min_y){
      p[[2]] = min_y
    }
    dx = (p-old_p)[[1]]
    trap_a = (dx * (p+old_p)[[2]])/2
    area = area + trap_a
    old_p = p
    
  }
  
  p = c(max_x, old_p[[2]])
  dx = (p-old_p)[[1]]
  trap_a = (dx * (p+old_p)[[2]])/2
  area = area + trap_a
  return(area)
}

# comparison analysis and plot

setwd("F:\\PycharmProjects\\evo_model")
comp_data = read.csv("comparison_data_2.csv")
max_x = max(comp_data$l0)
max_y = max(comp_data$eval.loss)
plot_data = add_pareto(comp_data, "language", "l0", "eval.loss", max_x, max_y)%>% mutate(eval.loss = ifelse(eval.loss < 0, 0, eval.loss))%>%mutate(across(language,factor,levels=c("compositional","holistic","nonconcatenative")))


ggplot(comp_data, aes(y=eval.loss,x=l0,color=log(lambda))) + geom_point() + facet_wrap(~language)+coord_cartesian(xlim=c(0, 5000))


ggplot(comp_data%>%filter(language!="nonconcatenative"), aes(x=l0, y=eval.loss, color=language, group=language)) +geom_point(color="gray") + facet_grid(.~language, labeller = as_labeller(c("compositional" = "Compositional", "holistic"="Holistic")))+
  geom_ribbon(data = plot_data %>% filter(is.pareto)%>%filter(language!="nonconcatenative") %>% arrange(language, l0), aes(fill=language, ymax = eval.loss, ymin=0), alpha=.25)+geom_point(data=comp_data %>% filter(abs(eval.loss)<10e-3)%>%filter(language!="nonconcatenative"))+
  coord_cartesian(ylim=c(0,max_y), xlim=c(0,5000)) + theme_bw() + xlab("Number of parameters (expected value)") + ylab("Average Cross Entropy loss (per character)") + 
  scale_color_manual(labels=c("Compositional", "Holistic"), values = c("#E69F00", "#56B4E9")) + scale_fill_manual(labels=c("Compositional", "Holistic"), values =  c("#E69F00", "#56B4E9"))+labs(color="Language", fill="Language") +
  theme(text = element_text(size=12))+theme(legend.position="none")


languages = unique(comp_data["language"])
max_x = max(comp_data[,"l0"])
max_y = max(comp_data[,"eval.loss"])
min_x = min(comp_data[,"l0"])
min_y = 0
prefix_area <- trap_under_pareto(comp_data, "language", "compositional", "l0", "eval.loss", max_x, max_y, min_x, min_y)
holistic_area <- trap_under_pareto(comp_data, "language", "holistic", "l0", "eval.loss", max_x, max_y, min_x, min_y)
infix_area <- trap_under_pareto(comp_data, "language", "nonconcatenative", "l0", "eval.loss", max_x, max_y, min_x, min_y) 
i_p_diff = infix_area - prefix_area
h_p_diff = holistic_area - prefix_area
h_i_diff = holistic_area - infix_area

print(i_p_diff)
print(h_p_diff)
print(h_i_diff)

i_p_diff_bigger <- rep(NA, 1000)
i_p_df = comp_data %>% filter(language == "compositional" | language == "nonconcatenative")
for (i in 1:1000){
  sample = i_p_df
  sampled_lang = sample(i_p_df$language)
  sample$language <- sampled_lang
  sample_p_area <- trap_under_pareto(sample, "language", "compositional", "l0", "eval.loss", max_x, max_y, min_x, min_y)
  
  sample_i_area <- trap_under_pareto(sample, "language", "nonconcatenative", "l0", "eval.loss", max_x, max_y, min_x, min_y)
  
  i_p_diff_bigger[i] = abs(sample_i_area-sample_p_area) > abs(i_p_diff)
  
}
print(sum(i_p_diff_bigger,na.rm=TRUE) / 1000)


h_p_diff_bigger <- rep(NA, 1000)
h_p_df = comp_data %>% filter(language == "compositional" | language == "holistic")
for (i in 1:1000){
  sample = h_p_df
  sampled_lang = sample(h_p_df$language)
  sample$language <- sampled_lang
  sample_p_area <- trap_under_pareto(sample, "language", "compositional", "l0", "eval.loss", max_x, max_y, min_x, min_y)
  
  sample_h_area <- trap_under_pareto(sample, "language", "holistic", "l0", "eval.loss", max_x, max_y, min_x, min_y)
  
  h_p_diff_bigger[i] = abs(sample_h_area-sample_p_area) > abs(h_p_diff)
  
}
print(sum(h_p_diff_bigger,na.rm=TRUE) / 1000)

h_i_diff_bigger <- rep(NA, 1000)
h_i_df = comp_data %>% filter(language == "nonconcatenative" | language == "holistic")
for (i in 1:1000){
  sample = h_i_df
  sampled_lang = sample(h_i_df$language)
  sample$language <- sampled_lang
  sample_h_area <- trap_under_pareto(sample, "language", "holistic", "l0", "eval.loss", max_x, max_y, min_x, min_y)
  
  sample_i_area <- trap_under_pareto(sample, "language", "nonconcatenative", "l0", "eval.loss", max_x, max_y, min_x, min_y)
  
  h_i_diff_bigger[i] = abs(sample_h_area-sample_i_area) > abs(h_i_diff)
  
}
print(sum(h_i_diff_bigger,na.rm=TRUE) / 1000)

